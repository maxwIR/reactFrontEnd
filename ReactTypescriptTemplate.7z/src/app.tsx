import * as React from "react";
import * as ReactDOM from "react-dom";
import Obj1 from './obj1';
import registerServiceWorker from './registerServiceWorker';

ReactDOM.render(
<div>
   HIIIIII
   <Obj1 />
</div>,
   document.getElementById("root")
);
registerServiceWorker();