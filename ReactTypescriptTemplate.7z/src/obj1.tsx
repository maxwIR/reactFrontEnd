import * as React from 'react';
import { FaTrash } from 'react-icons/fa';
import { FaPenNib } from 'react-icons/fa';

class Obj1 extends React.Component {
	constructor(props: Readonly<{}>) {
		super(props)
		this.edit = this.edit.bind(this)
		this.remove = this.remove.bind(this)
	}
	edit() {
		alert('edit triggered')
	}
	remove() {
		alert('remove triggered')
	}
	render() {
		return (
			<div className="note">
				<p>Learn React</p>
				<span>
					<button onClick={this.edit} id="edit"><FaPenNib /></button>
					<button onClick={this.remove} id="remove"><FaTrash /></button>
				</span>
			</div>
		)
	}
}

export default Obj1;